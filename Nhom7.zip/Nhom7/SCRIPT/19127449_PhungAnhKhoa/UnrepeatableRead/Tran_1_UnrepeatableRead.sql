﻿USE HTDCHO
go

--B2: Xuất số lượng hợp đồng hết hạn
EXEC SP_HopDongHetHang

--EXEC SP_HopDongHetHang_fix
