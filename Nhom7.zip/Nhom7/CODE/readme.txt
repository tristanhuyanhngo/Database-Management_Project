// khởi tạo 
npm i
// chạy chương trình
npm run start
