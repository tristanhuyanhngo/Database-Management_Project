import db from "../../utils/db.js";

export default {
  async pendingContract(result) {
    try {
      const pool = await db.conn;

      const sqlstring =
        "select * from HopDong where HopDong.TinhTrang = N'Chờ duyệt'";
      return pool.request().query(sqlstring, (e, data) => {
        for (let i = 0; i < data.recordset.length; i++) {
          if (data.recordset[i].ThoiGianHieuLuc != null) {
            let dd = data.recordset[i].ThoiGianHieuLuc.getDate();
            let mm = data.recordset[i].ThoiGianHieuLuc.getMonth() + 1;
            let yyyy = data.recordset[i].ThoiGianHieuLuc.getFullYear();
            data.recordset[i].ThoiGianHieuLuc = dd + "-" + mm + "-" + yyyy;
          }
        }

        if (data.recordset.length > 0) result(null, data.recordset);
        else result(true, null);
      });
    } catch {
      result(true, null);
    }
  },

  async renewalContract(result) {
    try {
      const pool = await db.conn;
      const sqlstring =
        "EXEC SP_HopDongHetHang";
      return await pool.request().query(sqlstring, (e, data) => {
        for (let i = 0; i < data.recordsets[0].length; i++) {
          if (data.recordsets[0][i].ThoiGianHieuLuc != null) {
            let dd = data.recordsets[0][i].ThoiGianHieuLuc.getDate();
            let mm = data.recordsets[0][i].ThoiGianHieuLuc.getMonth() + 1;
            let yyyy = data.recordsets[0][i].ThoiGianHieuLuc.getFullYear();
            data.recordsets[0][i].ThoiGianHieuLuc = dd + "-" + mm + "-" + yyyy;
          }
        }
        if (!e) result(null, data.recordsets);
        else result(true, null);
      });
    } catch {
      result(true, null);
    }
  },

  async renewalContract2(result) {
    try {
      const pool = await db.conn;
      const sqlstring =
        "EXEC SP_HopDongHetHang_fix";
      return await pool.request().query(sqlstring, (e, data) => {
        for (let i = 0; i < data.recordsets[0].length; i++) {
          if (data.recordsets[0][i].ThoiGianHieuLuc != null) {
            let dd = data.recordsets[0][i].ThoiGianHieuLuc.getDate();
            let mm = data.recordsets[0][i].ThoiGianHieuLuc.getMonth() + 1;
            let yyyy = data.recordsets[0][i].ThoiGianHieuLuc.getFullYear();
            data.recordsets[0][i].ThoiGianHieuLuc = dd + "-" + mm + "-" + yyyy;
          }
        }
        if (!e) result(null, data.recordsets);
        else result(true, null);
      });
    } catch {
      result(true, null);
    }
  },

  async updateState(id, result) {
    try {
      const pool = await db.conn;
      const sqlstring =
        "update hopdong set TinhTrang = N'Đã duyệt' where MaHopDong = @varID";
      return pool
        .request()
        .input("varID", db.sql.Int, id)
        .query(sqlstring, (e, data) => {
          if (!e) result(null, "thành công");
          else result(true, null);
        });
    } catch {
      result(true, null);
    }
  },

  async updateDate(id, date, result) {
    try {
      if(date!=null&&date!=undefined)
      {
        const pool = await db.conn;
        const sqlstring =
          "EXEC SP_GiaHanHopDong @varID, @varDate";
        return pool
          .request()
          .input("varDate", db.sql.Date, date)
          .input("varID", db.sql.Int, id)
          .query(sqlstring, (e, data) => {
            if (!e) result(null, "thành công");
            else result(true, null);
          });
      }
      else result(true, null);
     
    } catch {
      result(true, null);
    }
  },

  async updateDate2(id, date, result) {
    try {
      if(date!=null&&date!=undefined)
      {
        const pool = await db.conn;
        const sqlstring =
          "EXEC SP_GiaHanHopDong_fix @varID, @varDate";
        return pool
          .request()
          .input("varDate", db.sql.Date, date)
          .input("varID", db.sql.Int, id)
          .query(sqlstring, (e, data) => {
            if (!e) result(null, "thành công");
            else result(true, null);
          });
      }
      else result(true, null);
     
    } catch {
      result(true, null);
    }
  },

  async mail(id, result) {
    try {
      const pool = await db.conn;
      const sqlstring =
        "select doitac.MaSoThue as id, doitac.TenDoitac as name  from hopdong,doitac where MaHopDong = @varID and doitac.masothue = hopdong.masothue";
      return pool
        .request()
        .input("varID", db.sql.Int, id)
        .query(sqlstring, (e, data) => {
          if (!e) result(null, data.recordset[0]);
          else result(true, null);
        });
    } catch {
      result(true, null);
    }
  },

  async sendMail(id, msg, result) {
    try {
      const pool = await db.conn;
      const sqlstring =
        "insert into ThongBao(MaSoThue,NoiDung) values(@varID, @varMSG)";
      return pool
        .request()
        .input("varID", db.sql.Int, id)
        .input("varMSG", db.sql.NVarChar, msg)
        .query(sqlstring, (e, data) => {
          if (!e) result(null, "Thành công");
          else result(true, null);
        });
    } catch {
      result(true, null);
    }
  },
};
