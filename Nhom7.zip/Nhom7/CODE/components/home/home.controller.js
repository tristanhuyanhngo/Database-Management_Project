export function paging(req, res) {
  res.render('home/views/home');
}
